###########################################################################
# 
# This script contains a demonstration of the OPTIMISATION functionality in the
# 'kopls' package using a simulated data set. The data set is
# represented by 1000 spectral variables from two different classes
# and is available in the an attached data set. The
# demonstration essentially consists of two main steps.
#
# This demo focuses on demonstrating functionality for kernel parameter
# optimisation using grid search or simulated annealing. A nested cross-validation
# procedure is used when optimising the kernel parameter to minimize risk
# for model ovefitting. Optimisation and model results are also visualised.
# 
#
# ** THE 'koplsExample' DATA SET
# The 'koplsExample' data set contains the following objects:
#   Xtr = The training data matrix, with 400 observations and
#       1000 spectral variables.
#   Xte = The test data matrix, with 400 observations and
#       1000 spectral variables.
#   Xtro = Same data as 'Xtr', but with class-specific systematic
#       noise added.
#   Xteo = Same data as 'Xte', but with class-specific systematic
#       noise added.
#   Ytr = A binary matrix of class assignments for the training data.
#   Yte = A binary matrix of class assignments for the test data.
#   pch.vec = A vector with character indices (for plotting)
#   col.vec = A vector with colors (for plotting)
#
#
# ** INSTRUCTIONS
# 1) library(kopls)
# 2) demo(koplsOptimisationDemo)
#
###########################################################################
#
# Authors: Max Bylesjo, Umea University and Judy Fonville and Mattias 
# Rantalainen, Imperial College
#   
# Copyright (c) 2007-2010 Max Bylesjo, Judy Fonville and Mattias Rantalainen 
#
###########################################################################
#
# This file is part of the K-OPLS package.
#
# The K-OPLS package is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License version 2
# as published by the Free Software Foundation.
#
# The K-OPLS package is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
###########################################################################


## Load library and data set
library(kopls)
data(koplsExample)

######## START OF DEMO

########### Automated optimisation, evaluated using nested cross validation, 
########### of the kernel parameter using grid search or simulated annealing
## Time analysis to demonstrate GS and SA optimisations:
Xtr2=Xtr[seq(1,400,by=20),]
Ytr2=as.matrix(c(1:10,1:10))
col.vecs=col.vec[seq(1,400,by=20)]

## Plot PCA score vectors to demonstrate data set properties, also
## demonstrate 'time' dependency of data
svd2.res<-svd(Xtr2, nu=2, nv=2)

## Plot PCA score vectors to demonstrate data set properties
dev.new()
plot(svd2.res$u[,1], svd2.res$u[,2], col=col.vecs, pch=pch.vec, xlab="PC1", ylab="PC2", main="PCA of time data set")
text(svd2.res$u[,1]+0.01, svd2.res$u[,2],Ytr2)


## try and predict the timepoint Ytimetr, optimise the kernel parameter settings
## and model using gridsearch between 1 and 30 in 29 steps
GSmodel<-koplsCVopt(X=Xtr2,Y=Ytr2,A=1,oax=3,opt='GS',modelType='re',kernelParams=c(1,30,29),nrcvouter=5) 

## to plot the gridsearch results
koplsPlotOptResults(model=GSmodel,modelType='re',optmethod='GS')

## Optimise the kernel parameter settings and model using simulated
## annealing, fast cooling and a Gaussian kernel are used with 5 outer
## cross validation loops (nrcvouter), and 10 inner cross-validation 
## loops (default), 'verbose',TRUE would display the cross-validation and
## SA optimisation schedule.
SAmodelre<-koplsCVopt(X=Xtr2,Y=Ytr2,A=1,oax=3,modelType='re',opt='SA',kernelType='g',verbose=FALSE,t0=10,rt=0.2,nrcvouter=5)

## to plot the simulated annealing results
koplsPlotOptResults(model=SAmodelre,modelType='re',optmethod='SA')
# note that not all evaluated points are plotted, for clarity.

## other test data set
Xtr3=Xtro[seq(1,400,by=10),]
Ytr3=as.matrix(c(1:20,1:20))
col.vecs=col.vec[seq(1,400,by=10)]
## gridsearch with a polynomial function
GSmodelpoly=koplsCVopt(X=Xtr3,Y=Ytr3,A=1,oax=4,modelType='re',kernelParams=c(1, 5,4),opt='GS',kernelType='p',cvType='nfold')
## to plot the gridsearch results
koplsPlotOptResults(model=GSmodelpoly,modelType='re',optmethod='GS')

## Optimize the distorted model using simulated annealing,, using area
## under ROC curve, 'daAUC' and based on the distorted the data;
## simulated annealing with (20 outer loops so might take a few minutes)
Xtr4=Xtro[c(1:15,201:215),]
Ytr4=as.matrix(Ytr[c(1:15,201:215),])
colvecs4=col.vec[c(1:15,201:215)]
pchvecs4=pch.vec[c(1:15,201:215)]

## simulated annealing
SAmodelda<-koplsCVopt(X=Xtr4,Y=Ytr4,A=1,oax=1,modelType='daAUC',nrcvouter=5)

## plot of the optimisation:
koplsPlotOptResults(model=SAmodelda,modelType='daAUC');

## a plot of the predictive and orthogonal scores:
dev.new()
plot(SAmodelda$koplsModel$T,SAmodelda$koplsModel$To, col=colvecs4, pch=pchvecs4, xlab="Predictive component", ylab="Orthogonal Component", main="Score plot of SA-K-OPLS discriminant analysis model")

